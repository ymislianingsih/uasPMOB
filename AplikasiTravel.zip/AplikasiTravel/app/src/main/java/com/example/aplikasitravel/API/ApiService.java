package com.example.aplikasitravel.API;


import com.example.aplikasitravel.Login.ResponseLogin;
import com.example.aplikasitravel.Register.ResponseRegister;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {


    @FormUrlEncoded
    @POST("register.php")
    Call<ResponseRegister> registerUser(
            @Field("email") String email,
            @Field("fullname") String fullname,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("login.php")
    Call<ResponseLogin> loginuser(
            @Field("email") String email,
            @Field("password") String password
    );

}
